AI Assistance Declaration: I used OpenAI ChatGPT (GPT-6) on October 31, 2026 for drafting Markdown documentation, example R code, and proposed reflection responses. Prompts used: "Prepare the Assignment 1 files using the filename Sabouh_Mohamed_CA_BDA400_A01" (context: provided BDA400 Assignment 1 instructions); additional prompts are recorded in AI_Prompts_and_Responses.md. I have not yet independently verified the rendered files or executed the R code in RStudio; these checks must be completed and this declaration updated by the student. All final calculations must be completed and verified by myself. I am responsible for the accuracy and originality of this work.

# AI Prompt and Response Record

## Actual request made on October 31, 2026

**User request:** "yes" in response to the offer: "Would you like me to prepare the Assignment 1 files using your previously requested filename, `Sabouh_Mohamed_CA_BDA400_A01`?"

**Instructions supplied:** The five-page BDA400 Assignment 1 PDF, titled *Markdown Buddy Use ChatGPT to Draft and Format R Docs*.

**AI tool/version:** OpenAI ChatGPT (GPT-6).

**Key AI response/work:** Drafted a `README.md`, a synthetic-data example R script, a script-documenting `.Rmd`, a reflections draft based on proposed questions, and this disclosure/checklist. The README contains project overview, installation, sample code, license status, and disclosures. The `.Rmd` describes purpose, inputs, methods, and outputs.

## Suggested prompts from assignment handout (not claimed as separately run)

- "Explain what sections a good GitHub README for an R data analysis project should include."
- "Revise the sections list so it’s concise and uses Markdown headers and bullet formatting."
- "Check the Markdown syntax for correctness and readability."
- "Here’s a summary of my R project: [paste summary]. Generate a professional README.md file using Markdown."
- "Add sections for Installation, Example Code, and License. Keep tone concise and professional."
- "Review the Markdown for syntax errors and suggest 2 improvements for clarity."
- "Here’s my R script description. Suggest Markdown formatting and code block examples."
- "Add syntax highlighting and improve section organization (e.g., # Purpose, ## Inputs, ## Outputs)."
- "Is the Markdown consistent with RMarkdown best practices?"

## Draft refinements made by AI

1. Converted the repository inventory into a Markdown table and used fenced R code blocks.
2. Clarified that the data are entirely synthetic and code execution has not been independently verified.
3. Used section headings in the `.Rmd` to separate inputs, method, and outputs.

## Verification record (student must complete truthfully)

- [ ] Read official GitHub Markdown guidance and compare the README outline with a real tidyverse-related GitHub README.
- [ ] Preview README in GitHub and correct any rendering problems.
- [ ] Open and run `sales_summary.R` in RStudio or Posit Cloud.
- [ ] Recalculate row values and at least one category total independently; record the checked values.
- [ ] Knit `sales_summary.Rmd`; inspect headings, code, and bar chart.
- [ ] Compare the executed R code to the explanations in the README and Rmd.
- [ ] Confirm the instructor's three actual reflection questions and revise `Reflection.md`.
- [ ] Write down exact personal revisions and any screenshots or evidence.
- [ ] Create a GitHub repository named `markdown-buddy-sabouh-mohamed`, upload finished files, and verify their online preview.
- [ ] Update the AI Assistance Declaration to describe completed verification accurately.
- [ ] Submit through LMS following the instructor's submission page directions.

**Reminder:** No RStudio run, GitHub upload, real preview, or manual cross-check was performed by the assistant.

## Additional assistance (October 31, 2026)

The user asked the assistant to complete all remaining steps possible. The assistant reviewed package contents, parsed Markdown with Pandoc, inspected R code chunks, performed an independent arithmetic sanity check outside R, checked the connected GitHub account and repository existence, and generated `Verification_Report.md`. No RStudio execution, personal student calculations, instructor reflection question confirmation, or GitHub publication was completed.
