AI Assistance Declaration: I used OpenAI ChatGPT (GPT-6) on October 31, 2026 for drafting Markdown documentation, example R code, and proposed reflection responses. Prompts used: "Prepare the Assignment 1 files using the filename Sabouh_Mohamed_CA_BDA400_A01" (context: provided BDA400 Assignment 1 instructions); additional prompts are recorded in AI_Prompts_and_Responses.md. I have not yet independently verified the rendered files or executed the R code in RStudio; these checks must be completed and this declaration updated by the student. All final calculations must be completed and verified by myself. I am responsible for the accuracy and originality of this work.

# Reflection — Draft for Student Review

**Important:** The supplied five-page assignment requires answers to *three reflection questions* but does not print the questions themselves. These are three **proposed questions**, not quotations from the instructor. Replace them if the instructor supplied separate official questions. Personalize the answers to reflect what you actually did.

## Proposed Question 1: How did AI help you write and organize project documentation?

**Draft response:** AI suggested a consistent README structure with an overview, requirements, installation instructions, usage examples, and disclosure. I can use this as a starting point, then check whether each section accurately matches my R script. Its biggest benefit is making an unfamiliar documentation format easier to plan.

## Proposed Question 2: What limitations or risks did you notice in AI-generated documentation?

**Draft response:** AI-generated documentation may look complete while describing code that was never tested or suggesting instructions that do not apply to the project. I therefore need to compare the README with the actual script, check Markdown previews, and knit the R Markdown file. Any unverified claims must be removed or clearly labeled.

## Proposed Question 3: How will you use AI ethically in future R documentation projects?

**Draft response:** I will disclose which AI tool and prompts I used, review and edit its text myself, avoid sharing real or personal data, and independently verify code and calculated results. I will keep a concise record of revisions so another reviewer can understand the work.

## Student Completion Note

These are example answers only. Add specific observations from **your own** preview, RStudio testing, manual checks, and revisions before submitting.
