AI Assistance Declaration: I used OpenAI ChatGPT (GPT-6) on October 31, 2026 for drafting Markdown documentation, example R code, and proposed reflection responses. Prompts used: "Prepare the Assignment 1 files using the filename Sabouh_Mohamed_CA_BDA400_A01" (context: provided BDA400 Assignment 1 instructions); additional prompts are recorded in AI_Prompts_and_Responses.md. I have not yet independently verified the rendered files or executed the R code in RStudio; these checks must be completed and this declaration updated by the student. All final calculations must be completed and verified by myself. I am responsible for the accuracy and originality of this work.

# Synthetic Sales Summary in R

A small, reproducible R example demonstrating how to document an analytics workflow with a professional GitHub README. All records are **synthetic**, with no real customer or company data.

## Overview

This project uses base R to summarize synthetic sales by category, calculate total revenue, and display a bar chart. It is primarily a **documentation exercise** for BDA400 Assignment 1.

## Repository Contents

| File | Purpose |
| --- | --- |
| `README.md` | Project overview, setup, and example usage |
| `sales_summary.R` | R script for generating and summarizing synthetic sales |
| `sales_summary.Rmd` | R Markdown explanation of the script's inputs, steps, and outputs |
| `Reflection.md` | Draft responses to proposed reflection questions; confirm the actual questions |
| `AI_Prompts_and_Responses.md` | Prompt history, AI disclosure, and verification checklist |

## Requirements

- R (a recent version; no add-on packages required)
- RStudio or Posit Cloud, recommended for previewing the `.Rmd`
- Optional: `rmarkdown` and a rendering engine to knit the `.Rmd`

## Installation

1. Download or clone this repository.
2. Open the project directory in RStudio.
3. Review `sales_summary.R` before running it.
4. Run the script from the project directory.

```r
source("sales_summary.R")
```

## Example Code

```r
sales <- data.frame(
  category = c("Books", "Books", "Games", "Games", "Art"),
  units = c(2, 1, 3, 2, 4),
  unit_price = c(15, 20, 12, 12, 8)
)
sales$revenue <- sales$units * sales$unit_price
aggregate(revenue ~ category, data = sales, FUN = sum)
```

## Expected Outputs

The script prints a category-level revenue table and plots a category revenue bar chart to the R graphics device. Figures are not committed as evidence of execution.

## Documentation and Validation

Review the README with GitHub's Markdown preview; use RStudio/Posit Cloud to review or knit `sales_summary.Rmd`. Run the script and check the table against a manual calculation. These steps **have not been performed** by the assistant and must be completed by the student.

## License

This classroom example is supplied for educational use. **No open-source license has been assigned.** Add a `LICENSE` file only if you decide to grant reuse rights.

## AI Assistance Disclosure

- **Tool:** OpenAI ChatGPT (GPT-6), October 31, 2026.
- **Main prompts:** Request to prepare BDA400 Assignment 1 files from the provided instructions; see `AI_Prompts_and_Responses.md` for the complete record and instructor-suggested prompt examples.
- **AI-supported changes:** Added clear section headings, a repository contents table, syntax-highlighted code fences, and explicit setup and validation steps.
- **Student verification/editing:** Pending. Check the rendered Markdown, run the R example, document the adjustments you personally make, and update the declaration above before submitting.

## Additional automated checks (October 31, 2026)

A Markdown-to-HTML **parsing check** using Pandoc succeeded for this README, the reflection draft, the prompt appendix, and the Rmd Markdown content. These checks do not establish that GitHub preview or RStudio knitting succeeds. An assistant-side independent arithmetic check yielded expected synthetic category totals of Art = 32, Books = 50, and Games = 60; the student must verify these independently. See `Verification_Report.md`.
