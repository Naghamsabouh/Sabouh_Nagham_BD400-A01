# AI Assistance Declaration: I used OpenAI ChatGPT (GPT-6) on October 31, 2026 to draft this synthetic example script. I have not executed or independently verified it; the student must run and check all outputs. Prompts and verification status are in AI_Prompts_and_Responses.md. All final calculations must be done and checked by the student, who is responsible for the submitted work.

# Synthetic category sales summary (no real personal data)
sales <- data.frame(
  category = c("Books", "Books", "Games", "Games", "Art"),
  units = c(2, 1, 3, 2, 4),
  unit_price = c(15, 20, 12, 12, 8)
)

# Each row's revenue is units times unit price.
sales$revenue <- sales$units * sales$unit_price

# Summarize total revenue for each category.
category_totals <- aggregate(revenue ~ category, data = sales, FUN = sum)
print(category_totals)

# Display a simple plot in the active graphics device.
barplot(category_totals$revenue,
        names.arg = category_totals$category,
        main = "Synthetic Revenue by Category",
        ylab = "Revenue (synthetic units)")
